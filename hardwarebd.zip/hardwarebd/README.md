# HardwareBD.com (static site)
Edit the CONFIG block at the top of script.js (WhatsApp number with country code, phone, email, address) and the Google Maps address in index.html.
## Free hosting
**GitHub Pages**: new repo, upload the files, Settings > Pages > Deploy from branch `main` / root. Live at `username.github.io/repo`.
**Netlify**: app.netlify.com > Add new site > Deploy manually, drag the folder in. Free `name.netlify.app`.
**Cloudflare Pages**: Workers & Pages > Create > Pages > Upload assets, upload the folder. Free `name.pages.dev`.
## Demo admin warning
The product manager (footer link "Admin (demo)") saves to the visitor's own browser localStorage. It is not secure, has no login, and changes are not shared with other visitors. Use it only to try the idea.
