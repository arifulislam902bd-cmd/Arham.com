// ===== EDIT THESE =====
const CONFIG={whatsapp:"8801XXXXXXXXX",phone:"+880 1XXX-XXXXXX",email:"info@example.com",address:"Your business address, Dhaka, Bangladesh"};
const CATS={"Hardware":["Power Tools","Hand Tools","Electrical Products","Plumbing Materials","Construction Materials","Safety Equipment"],
"Chemicals":["Industrial Chemicals","Cleaning Chemicals","Water Treatment Chemicals","Paint & Coating Chemicals","Adhesives","Laboratory Chemicals"],
"Industrial Equipment":["Generators & Compressors","Welding Equipment","Pumps & Motors"]};
const ICON={"Power Tools":"drill","Hand Tools":"hammer","Electrical Products":"plug","Plumbing Materials":"faucet","Construction Materials":"trowel-bricks","Safety Equipment":"helmet-safety","Industrial Chemicals":"flask","Cleaning Chemicals":"spray-can-sparkles","Water Treatment Chemicals":"droplet","Paint & Coating Chemicals":"paint-roller","Adhesives":"fill-drip","Laboratory Chemicals":"vial","Generators & Compressors":"bolt","Welding Equipment":"fire-flame-curved","Pumps & Motors":"gears"};
const SEED=[
{id:1,name:"Cordless Drill 18V",group:"Hardware",cat:"Power Tools",price:7800,stock:15,best:true,desc:"18V cordless drill driver with two batteries and charger."},
{id:2,name:"Claw Hammer 500g",group:"Hardware",cat:"Hand Tools",price:650,stock:60,best:false,desc:"Forged steel head with anti-slip grip."},
{id:3,name:"Copper Electrical Cable 90m",group:"Hardware",cat:"Electrical Products",price:5200,stock:25,best:true,desc:"Insulated copper wire coil for house wiring."},
{id:4,name:"PVC Pipe Fitting Set",group:"Hardware",cat:"Plumbing Materials",price:980,stock:40,best:false,desc:"Assorted elbows, tees and couplers."},
{id:5,name:"Cement 50kg Bag",group:"Hardware",cat:"Construction Materials",price:0,stock:200,best:false,desc:"Price changes often. Contact us for today's rate."},
{id:6,name:"Safety Helmet",group:"Hardware",cat:"Safety Equipment",price:420,stock:80,best:true,desc:"Adjustable industrial hard hat."},
{id:7,name:"Floor Cleaner 5L",group:"Chemicals",cat:"Cleaning Chemicals",price:850,stock:35,best:true,desc:"Concentrated floor cleaner. Follow label directions."},
{id:8,name:"Epoxy Adhesive Kit",group:"Chemicals",cat:"Adhesives",price:560,stock:50,best:false,desc:"Two-part epoxy for metal, wood and ceramic."},
{id:9,name:"Industrial Paint 4L",group:"Chemicals",cat:"Paint & Coating Chemicals",price:0,stock:30,best:false,desc:"Bulk colors available. Contact us for a quote."},
{id:10,name:"Water Treatment Chemical",group:"Chemicals",cat:"Water Treatment Chemicals",price:0,stock:20,best:false,desc:"Sold to business customers. Ask for the safety data sheet."},
{id:11,name:"Portable Generator 3kVA",group:"Industrial Equipment",cat:"Generators & Compressors",price:0,stock:5,best:true,desc:"Petrol generator for site and backup use."},
{id:12,name:"Inverter Welding Machine",group:"Industrial Equipment",cat:"Welding Equipment",price:18500,stock:8,best:false,desc:"Compact arc welder for workshops."}];
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const bdt=n=>"৳"+Number(n).toLocaleString("en-BD");
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch{return d}};
const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
let products=load("hbd_products",SEED),cart=load("hbd_cart",[]);
const wa=t=>`https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(t)}`;
const allCats=()=>Object.values(CATS).flat();

// Contact info + links
$$("[data-c]").forEach(e=>e.textContent=CONFIG[e.dataset.c]);
$("[data-tel]").textContent=CONFIG.phone;$("[data-tel]").href="tel:"+CONFIG.phone.replace(/\s|-/g,"");
$("[data-mail]").textContent=CONFIG.email;$("[data-mail]").href="mailto:"+CONFIG.email;
["#heroWa","#floatWa","#floatWa2"].forEach(s=>$(s).href=wa("Hello, I need help with an order."));

// Nav
$("#burger").onclick=()=>$("#menu").classList.toggle("open");
$$("#menu a").forEach(a=>a.onclick=()=>$("#menu").classList.remove("open"));

// Categories
$("#catGrid").innerHTML=allCats().map(c=>`<button data-cat="${esc(c)}"><i class="fa-solid fa-${ICON[c]}"></i>${esc(c)}</button>`).join("");
$$("#catGrid button").forEach(b=>b.onclick=()=>{$("#grp").value="";fillCats();$("#cat").value=b.dataset.cat;drawGrid();location.hash="products"});
function fillCats(){const g=$("#grp").value,list=g?CATS[g]:allCats();$("#cat").innerHTML='<option value="">All categories</option>'+list.map(c=>`<option>${esc(c)}</option>`).join("")}
fillCats();$("#grp").onchange=()=>{fillCats();drawGrid()};$("#cat").onchange=drawGrid;$("#q").oninput=drawGrid;

// Products
function card(p){const img=p.img?`style="background-image:url('${esc(p.img)}')"`:"";
 return `<article class="pc"><div class="pimg" ${img} data-view="${p.id}" role="button" tabindex="0" aria-label="View ${esc(p.name)}">${p.img?"":`<i class="fa-solid fa-${ICON[p.cat]||"box"}"></i>`}</div>
 <div class="pb"><span class="tag">${esc(p.cat)}</span><h3>${esc(p.name)}</h3><span class="price">${p.price>0?bdt(p.price):"Contact for price"}</span>
 ${p.stock>0?"":'<span class="out">Out of stock</span>'}<div class="row"><button class="btn ghost dark" data-view="${p.id}">Details</button>
 ${p.price>0&&p.stock>0?`<button class="btn pri" data-add="${p.id}">Add</button>`:`<a class="btn pri" target="_blank" rel="noopener" href="${wa("Please send price for: "+p.name)}">Get price</a>`}</div></div></article>`}
function drawGrid(){const q=$("#q").value.trim().toLowerCase(),g=$("#grp").value,c=$("#cat").value;
 const l=products.filter(p=>(!g||p.group===g)&&(!c||p.cat===c)&&(!q||(p.name+p.cat+p.desc).toLowerCase().includes(q)));
 $("#count").textContent=l.length+" product"+(l.length===1?"":"s");$("#grid").innerHTML=l.length?l.map(card).join(""):'<p class="muted">No products match. Try another search or category.</p>';
 $("#best").innerHTML=products.filter(p=>p.best).map(card).join("")||'<p class="muted">No best sellers selected.</p>'}
document.addEventListener("click",e=>{const v=e.target.closest("[data-view]"),a=e.target.closest("[data-add]"),cl=e.target.closest("[data-close]");
 if(v)openProduct(+v.dataset.view);if(a){addCart(+a.dataset.add)}if(cl){cl.closest(".modal")?cl.closest(".modal").classList.remove("open"):$("#cart").classList.remove("open")}
 if(e.target.classList.contains("modal"))e.target.classList.remove("open")});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){$$(".modal.open").forEach(m=>m.classList.remove("open"));$("#cart").classList.remove("open")}
 if(e.key==="Enter"&&e.target.dataset?.view)openProduct(+e.target.dataset.view)});
function openProduct(id){const p=products.find(x=>x.id===id);if(!p)return;
 $("#modalBody").innerHTML=`<h3>${esc(p.name)}</h3><p class="tag">${esc(p.group)} · ${esc(p.cat)}</p><p>${esc(p.desc)}</p><p class="price">${p.price>0?bdt(p.price):"Contact for price"}</p>
 <p>${p.stock>0?"In stock: "+p.stock:'<span class="out">Out of stock</span>'}</p><div class="btns">${p.price>0&&p.stock>0?`<button class="btn pri" data-add="${p.id}">Add to cart</button>`:""}
 <a class="btn ghost dark" target="_blank" rel="noopener" href="${wa("Hello, I want to know about: "+p.name)}"><i class="fa-brands fa-whatsapp"></i> Ask on WhatsApp</a></div>`;$("#modal").classList.add("open")}

// Cart
function addCart(id){const p=products.find(x=>x.id===id),i=cart.find(x=>x.id===id);if(!p)return;
 if((i?i.qty:0)>=p.stock){alert("Only "+p.stock+" in stock.");return}i?i.qty++:cart.push({id,qty:1});save("hbd_cart",cart);drawCart();$("#cart").classList.add("open");$("#modal").classList.remove("open")}
function drawCart(){cart=cart.filter(i=>products.some(p=>p.id===i.id));$("#cartCount").textContent=cart.reduce((a,i)=>a+i.qty,0);
 const rows=cart.map(i=>({p:products.find(p=>p.id===i.id),qty:i.qty}));const total=rows.reduce((a,r)=>a+r.p.price*r.qty,0);
 $("#cartBody").innerHTML=rows.length?rows.map(r=>`<div class="ci"><div><b>${esc(r.p.name)}</b><br><span class="muted">${bdt(r.p.price)}</span></div><div class="qty"><button data-q="${r.p.id}" data-d="-1" aria-label="Decrease">-</button>${r.qty}<button data-q="${r.p.id}" data-d="1" aria-label="Increase">+</button></div></div>`).join(""):'<p class="muted">Your cart is empty.</p>';
 $("#cartFoot").innerHTML=rows.length?`<p><b>Total: ${bdt(total)}</b> (delivery charge confirmed on WhatsApp)</p><input id="cn" class="tools" placeholder="Your name" style="width:100%;min-height:44px;margin-bottom:8px;padding:0 10px"><input id="cp" placeholder="Phone and delivery address" style="width:100%;min-height:44px;margin-bottom:8px;padding:0 10px"><p id="cerr" class="err"></p><button class="btn pri" id="order" style="width:100%"><i class="fa-brands fa-whatsapp"></i> Order on WhatsApp</button>`:"";
 save("hbd_cart",cart)}
$("#cartBody").addEventListener("click",e=>{const b=e.target.closest("[data-q]");if(!b)return;const id=+b.dataset.q,i=cart.find(x=>x.id===id),p=products.find(x=>x.id===id);
 i.qty+=+b.dataset.d;if(i.qty>p.stock){i.qty=p.stock;alert("Only "+p.stock+" in stock.")}if(i.qty<=0)cart=cart.filter(x=>x.id!==id);drawCart()});
$("#cartFoot").addEventListener("click",e=>{if(!e.target.closest("#order"))return;const n=$("#cn").value.trim(),c=$("#cp").value.trim();
 if(n.length<2||c.length<8){$("#cerr").textContent="Enter your name, phone and address.";return}
 const lines=cart.map(i=>{const p=products.find(x=>x.id===i.id);return `${i.qty} x ${p.name} (${bdt(p.price*i.qty)})`});
 window.open(wa(`New order\n${lines.join("\n")}\nTotal: ${bdt(cart.reduce((a,i)=>a+products.find(p=>p.id===i.id).price*i.qty,0))}\nName: ${n}\nContact: ${c}`),"_blank")});
$("#cartBtn").onclick=()=>$("#cart").classList.add("open");

// Inquiry form (opens WhatsApp; there is no server to store messages)
$("#inq").onsubmit=e=>{e.preventDefault();const f=new FormData(e.target),n=f.get("name").trim(),p=f.get("phone").trim(),m=f.get("msg").trim();
 if(n.length<2||p.length<8||m.length<5){$("#inqMsg").textContent="Please fill in all fields.";return}$("#inqMsg").textContent="";
 window.open(wa(`Inquiry from ${n} (${p}): ${m}`),"_blank")};

// Admin (DEMO, localStorage only)
function fillAdminSelects(){$("#pf [name=group]").innerHTML=Object.keys(CATS).map(g=>`<option>${esc(g)}</option>`).join("");$("#pf [name=cat]").innerHTML=allCats().map(c=>`<option>${esc(c)}</option>`).join("")}
function drawAdmin(){$("#adminList").innerHTML=products.map(p=>`<div class="al"><span>${esc(p.name)}<br><small>${p.price>0?bdt(p.price):"Contact"} · stock ${p.stock}</small></span><span><button data-edit="${p.id}">Edit</button> <button data-del="${p.id}">Delete</button></span></div>`).join("")||"<p>No products.</p>"}
$("#adminOpen").onclick=e=>{e.preventDefault();fillAdminSelects();drawAdmin();$("#admin").classList.add("open")};
$("#adminList").addEventListener("click",e=>{const ed=e.target.closest("[data-edit]"),de=e.target.closest("[data-del]");
 if(ed){const p=products.find(x=>x.id===+ed.dataset.edit),f=$("#pf");for(const k of["id","name","group","cat","price","stock","img","desc"])f.elements[k].value=p[k]??"";f.elements.best.checked=!!p.best}
 if(de&&confirm("Delete this product?")){products=products.filter(x=>x.id!==+de.dataset.del);save("hbd_products",products);drawAdmin();drawGrid();drawCart()}});
$("#pf").onsubmit=e=>{e.preventDefault();const f=e.target.elements,id=+f.id.value;
 const p={id:id||Date.now(),name:f.name.value.trim(),group:f.group.value,cat:f.cat.value,price:Math.max(0,+f.price.value),stock:Math.max(0,Math.floor(+f.stock.value)),img:f.img.value.trim(),desc:f.desc.value.trim(),best:f.best.checked};
 if(!p.name)return;products=id?products.map(x=>x.id===id?p:x):[...products,p];save("hbd_products",products);e.target.reset();f.id.value="";drawAdmin();drawGrid();drawCart()};
$("#pfReset").onclick=()=>{$("#pf").reset();$("#pf").elements.id.value=""};
$("#resetData").onclick=()=>{if(confirm("Restore the sample products?")){products=SEED;save("hbd_products",products);drawAdmin();drawGrid();drawCart()}};

// Scroll reveal
const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}}),{threshold:.1});
$$(".sec .card,.sec h2").forEach(el=>{el.classList.add("reveal");io.observe(el)});
drawGrid();drawCart();
